package org.dhbw.stuttgart.ita16.reqmaster.components;

import javax.swing.*;

/**
 * Adaption der Swing JLabel-Klasse fuer individuelle Anpassungen an das Projekt
 */
public class UILabel extends JLabel{

    JLabel uiLabel;

    /**
     * Konstruktor der Klasse
     */
    public UILabel() {
    }
}




