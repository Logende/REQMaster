package org.dhbw.stuttgart.ita16.reqmaster.view;

/**
 * Diese Klasse ermöglicht es, die View über den Aufruf der Methode zu aktualisieren
 */
public interface IObserverView {

    void update();

}
