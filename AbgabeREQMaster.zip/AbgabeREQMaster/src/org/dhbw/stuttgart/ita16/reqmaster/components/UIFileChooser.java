package org.dhbw.stuttgart.ita16.reqmaster.components;

import javax.swing.*;

/**
 * Adaption der Swing JFileChooser-Klasse fuer individuelle Anpassungen an das Projekt
 */
public class UIFileChooser extends JFileChooser {

    public UIFileChooser() {

    }
}
