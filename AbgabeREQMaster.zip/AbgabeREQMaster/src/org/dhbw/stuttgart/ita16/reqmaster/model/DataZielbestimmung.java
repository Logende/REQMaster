package org.dhbw.stuttgart.ita16.reqmaster.model;


/**
 * Datenklasse für Zielbestimmung.
 */
public class DataZielbestimmung extends DataText {

	public DataZielbestimmung(String text) {
		super(text);
	}



}
