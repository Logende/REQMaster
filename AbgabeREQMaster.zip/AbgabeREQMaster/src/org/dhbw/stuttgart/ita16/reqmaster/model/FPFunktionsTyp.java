package org.dhbw.stuttgart.ita16.reqmaster.model;


/**
 * Produktdaten und -funktionen werden in FPFunktiosnTypen eingeteilt.
 */
public enum FPFunktionsTyp {

	DATEN,
	TRANSAKTION

}
