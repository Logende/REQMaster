package org.dhbw.stuttgart.ita16.reqmaster.events;

public class UIActionAddProduktFunktionEvent extends UIActionAddEvent {

    public UIActionAddProduktFunktionEvent(){}
}
