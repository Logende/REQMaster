package org.dhbw.stuttgart.ita16.reqmaster.controller;


/**
 * Interface für den Controller des MVC pattern.
 */
public interface IController {

}
