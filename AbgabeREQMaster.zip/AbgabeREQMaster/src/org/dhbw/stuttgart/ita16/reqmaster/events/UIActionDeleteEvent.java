package org.dhbw.stuttgart.ita16.reqmaster.events;

class UIActionDeleteEvent extends UIActionEvent {

}
