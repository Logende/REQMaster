package org.dhbw.stuttgart.ita16.reqmaster.events;

public class UIActionAddProduktDatumEvent extends UIActionAddEvent {

    public UIActionAddProduktDatumEvent(){

    }
}
