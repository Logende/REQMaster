package org.dhbw.stuttgart.ita16.reqmaster.model;


/**
 * Datenklasse für Umgebung.
 */
public class DataUmgebung extends DataText {


	public DataUmgebung(String text) {
		super(text);
	}

}
