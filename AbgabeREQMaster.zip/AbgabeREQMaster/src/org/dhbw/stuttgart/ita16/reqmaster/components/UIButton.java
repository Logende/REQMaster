package org.dhbw.stuttgart.ita16.reqmaster.components;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Adaption der Swing JButton-Klasse fuer individuelle Anpassungen an das Projekt
 */
public class UIButton extends JButton {

    /**
     * Konstruktor der Klasse
     */
    public UIButton() {
    }
}

