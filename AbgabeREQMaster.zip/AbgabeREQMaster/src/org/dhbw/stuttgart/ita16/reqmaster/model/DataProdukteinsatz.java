package org.dhbw.stuttgart.ita16.reqmaster.model;


/**
 * Datenklasse für Produkteinsatz.
 */
public class DataProdukteinsatz extends DataText {


	public DataProdukteinsatz(String text) {
		super(text);
	}

}
