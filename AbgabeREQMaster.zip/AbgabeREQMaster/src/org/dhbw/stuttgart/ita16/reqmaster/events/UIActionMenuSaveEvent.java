package org.dhbw.stuttgart.ita16.reqmaster.events;

public class UIActionMenuSaveEvent extends UIActionMenuEvent {

    public UIActionMenuSaveEvent(){}
}
