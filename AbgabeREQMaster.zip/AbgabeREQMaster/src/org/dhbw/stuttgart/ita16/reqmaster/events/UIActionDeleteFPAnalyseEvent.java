package org.dhbw.stuttgart.ita16.reqmaster.events;


public class UIActionDeleteFPAnalyseEvent extends UIActionDeleteEvent {

	public UIActionDeleteFPAnalyseEvent() {
	}

}
