package org.dhbw.stuttgart.ita16.reqmaster.model;



public interface IDataAufwandsabschaetzung {

}
